# Proxy Hunter v6 — hosted edition

Deploy as a public website using Render Blueprint or Docker. This app is a best-effort public proxy feed collector and live verifier. It includes 12 configured public-feed repositories (some provide multiple protocol feeds); individual sources may be offline, rate-limited, changed, or return no candidates. Source availability is reported in scan status.

## Deploy on Render
1. Create a GitHub repository and upload the contents of this folder (not the enclosing ZIP folder).
2. In Render, choose **New → Blueprint** and connect that repository. Render reads `render.yaml`.
3. Set a strong `DASHBOARD_PASSWORD` in the service environment.
4. Deploy. The Render URL is your public website. Use HTTPS; do not leave the dashboard unprotected.

The service uses one Gunicorn worker because scan progress/results are held in process memory. Multiple workers would split state and cause inconsistent dashboard results. For persistent multi-user operation, use a shared database/queue architecture; this ZIP is a single-instance scanner, not a horizontally scalable service.

## Docker
`docker build -t proxy-hunter .` then `docker run -e PORT=5000 -e DASHBOARD_PASSWORD='use-a-long-password' -p 5000:5000 proxy-hunter`.

## Scan features
- All/specific country based on observed exit IP.
- 1–10,000 verified-result target; scans up to 3× candidates, capped at 30,000.
- All/HTTP/HTTPS/SOCKS4/SOCKS5 protocol selection.
- Public / Both / Private modes. Public feeds are automatically fetched. Private proxies are not enumerable from public internet; Private mode needs an authorized private inventory and this build intentionally does not fabricate results. Both mode currently scans public feeds and reports that private inventory is not connected.
- Live exit-IP, country, Google `generate_204` and latency check. Results are sorted by Google RTT; default ceiling 250ms.
- TXT export of currently verified results.

## Google status caveat
Google does not publish a universal public proxy allowlist/blacklist API. A 204 response is only a point-in-time reachability signal from the hosting server. It does not prove Google authorization, reputation, absence from every blocklist, or future access. This checker rejects non-204 responses and slow responses but cannot guarantee a proxy is unblocked everywhere.

## Operational and security notes
- Proxy checks originate from the hosting server, not the visitor's device.
- Public proxies are untrusted; never use them for credentials, sessions, banking, or sensitive data.
- The app uses in-memory state and is designed for one running web process. Render free instances may sleep; use an always-on paid instance for reliable scans.
- Do not expose an unauthenticated public scanner. Set `DASHBOARD_PASSWORD` and protect the URL.
- Public feed repositories and their contents are third-party data; no uptime or completeness guarantee.
