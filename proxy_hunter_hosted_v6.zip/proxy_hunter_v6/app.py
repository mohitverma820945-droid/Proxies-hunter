import os, re, time, threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote
import requests
from flask import Flask, jsonify, render_template, request
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
SCAN_TIMEOUT = max(4, min(int(os.getenv('SCAN_TIMEOUT_SECONDS', '10')), 25))
MAX_WORKERS = max(1, min(int(os.getenv('SCAN_WORKERS', '40')), 80))
# Default 250 ms is a practical high-quality ceiling; 50 ms is too restrictive for global proxy pools.
GOOGLE_MAX_LATENCY_MS = max(100, min(int(os.getenv('GOOGLE_MAX_LATENCY_MS', '250')), 10000))
GOOGLE_URL = 'https://www.google.com/generate_204'
ALLOWED = {'http', 'https', 'socks4', 'socks5'}
PROXY_RE = re.compile(r'^(?:(https?|socks4|socks5h?)://)?(?:(?:([^:@/\s]+):([^@/\s]+)@))?([^:/\s]+):(\d{1,5})$', re.I)
# 12 independently maintained public-feed repositories. Feeds are best-effort;
# each may be unavailable or rate-limited at scan time.
FEEDS = {
 'http': [
  ('ProxyScrape','https://cdn.jsdelivr.net/gh/proxyscrape/free-proxy-list@main/proxies/http/data.txt','http'),
  ('TheSpeedX','https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt','http'),
  ('Monosans','https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt','http'),
  ('Clarketm','https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt','http'),
  ('ShiftyTR','https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt','http'),
  ('Jetkai','https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt','http'),
  ('Mmpx12','https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt','http'),
  ('Zaeem20','https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt','http'),
  ('Proxy-list-download','https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt','http'),
  ('proxifly','https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt','http')],
 'https': [
  ('ProxyScrape-HTTPS','https://cdn.jsdelivr.net/gh/proxyscrape/free-proxy-list@main/proxies/https/data.txt','https'),
  ('proxifly-HTTPS','https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt','https')],
 'socks4': [
  ('ProxyScrape-SOCKS4','https://cdn.jsdelivr.net/gh/proxyscrape/free-proxy-list@main/proxies/socks4/data.txt','socks4'),
  ('TheSpeedX-SOCKS4','https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt','socks4'),
  ('Monosans-SOCKS4','https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt','socks4'),
  ('Jetkai-SOCKS4','https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt','socks4')],
 'socks5': [
  ('ProxyScrape-SOCKS5','https://cdn.jsdelivr.net/gh/proxyscrape/free-proxy-list@main/proxies/socks5/data.txt','socks5'),
  ('TheSpeedX-SOCKS5','https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt','socks5'),
  ('Monosans-SOCKS5','https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt','socks5'),
  ('Jetkai-SOCKS5','https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt','socks5'),
  ('hookzof-SOCKS5','https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt','socks5')]
}
lock=threading.Lock()
state={'running':False,'status':'idle','total':0,'checked':0,'working':[],'failed':0,'message':'Choose settings and start a scan.','started_at':None,'finished_at':None,'requested':0,'sources':[]}

def parse_lines(text, default_proto):
 out=[]; seen=set()
 for raw in text.splitlines():
  line=raw.strip()
  if not line or line.startswith('#'): continue
  m=PROXY_RE.match(line)
  if not m: continue
  scheme,user,pwd,host,port=m.groups()
  proto=(scheme or default_proto or 'http').lower().replace('socks5h','socks5')
  if proto not in ALLOWED: continue
  try: p=int(port)
  except ValueError: continue
  if not 1 <= p <= 65535: continue
  # Avoid DNS names: public feed scanners accept IP endpoints only.
  octets=host.split('.')
  if len(octets)!=4:
   continue
  try:
   if any(not 0 <= int(x) <= 255 for x in octets): continue
  except ValueError: continue
  key=(host,p,proto)
  if key in seen: continue
  seen.add(key)
  out.append({'ip':host,'port':p,'protocol':proto,'username':user,'password':pwd,'source':'public-feed','is_private':bool(user and pwd),'anonymity':'unrated','uptime_percent':None})
 return out

def fetch_public(country, protocol, maximum):
 selected=[protocol] if protocol!='all' else ['http','https','socks4','socks5']
 candidates=[]; errors=[]; inventory=[]; seen=set()
 sess=requests.Session(); sess.headers.update({'User-Agent':'ProxyHunter/5.0','Accept':'text/plain,*/*'})
 for proto in selected:
  for name,url,default_proto in FEEDS.get(proto,[]):
   try:
    r=sess.get(url,timeout=20); r.raise_for_status()
    rows=parse_lines(r.text,default_proto); added=0
    for row in rows:
     key=(row['ip'],row['port'],row['protocol'])
     if key in seen: continue
     seen.add(key); row['source']=name; candidates.append(row); added+=1
    inventory.append(f'{name}/{proto}: {added}')
   except Exception as e:
    errors.append(f'{name}/{proto}: {str(e)[:140]}')
 # Balance protocols so an 'all protocols' scan is not monopolized by HTTP feeds.
 buckets={p:[] for p in selected}
 for row in candidates: buckets.setdefault(row['protocol'],[]).append(row)
 balanced=[]
 while len(balanced)<maximum and any(buckets.values()):
  for p in selected:
   if buckets.get(p) and len(balanced)<maximum: balanced.append(buckets[p].pop(0))
 return balanced, errors, inventory

def verify_proxy(c):
 proto=c['protocol']; # HTTPS describes destination support, not TLS-to-proxy. Most HTTPS-capable
 # public proxies are ordinary HTTP CONNECT proxies.
 scheme='socks5h' if proto=='socks5' else ('socks4' if proto=='socks4' else 'http')
 auth=''
 if c.get('username'):
  auth=f"{quote(c['username'],safe='')}:{quote(c.get('password') or '',safe='')}@"
 proxy=f"{scheme}://{auth}{c['ip']}:{c['port']}"
 px={'http':proxy,'https':proxy}
 try:
  r=requests.get('https://api.ipify.org?format=json',proxies=px,timeout=SCAN_TIMEOUT,headers={'User-Agent':'ProxyHunter/5.0'})
  r.raise_for_status(); exit_ip=str(r.json().get('ip','')).strip()
  if not exit_ip: return None
  geo=requests.get(f'https://ipapi.co/{exit_ip}/json/',timeout=8,headers={'User-Agent':'ProxyHunter/5.0'})
  geo.raise_for_status(); country=(geo.json().get('country_code') or '').upper()
  if not country: return None
  gt=time.perf_counter()
  g=requests.get(GOOGLE_URL,proxies=px,timeout=SCAN_TIMEOUT,allow_redirects=False,headers={'User-Agent':'Mozilla/5.0 (compatible; ProxyHunter/5.0)'})
  google_ms=round((time.perf_counter()-gt)*1000)
  if g.status_code!=204 or google_ms>GOOGLE_MAX_LATENCY_MS: return None
  body=(g.text or '').lower()
  if any(marker in body for marker in ('unusual traffic','captcha','sorry/index','automated queries')): return None
  return {'ip':c['ip'],'port':c['port'],'protocol':proto.upper(),'country':country,'exit_ip':exit_ip,'latency_ms':google_ms,'google_latency_ms':google_ms,'google_status':204,'google_access':True,'quality':('EXCELLENT' if google_ms<=100 else 'HIGH' if google_ms<=200 else 'GOOD'),'anonymity':c.get('anonymity') or 'unrated','uptime_percent':None,'is_private':bool(c.get('is_private')),'username':c.get('username'),'password':c.get('password'),'source':c.get('source','public-feed'),'verified_at':time.time()}
 except Exception: return None

def run_scan(source,country,protocol,maximum):
 try:
  if source=='private':
   raise ValueError('Private proxies cannot be discovered from public feeds. Add an authorized private inventory to scan private proxies; this build does not invent private results.')
  # Over-fetch candidates so dead endpoints do not prevent reaching the requested
  # verified-result count. Hard cap keeps a 10k-result scan bounded.
  candidate_limit=min(maximum*3,30000)
  candidates,errors,inventory=fetch_public(country,protocol,candidate_limit)
  if not candidates:
   detail=' | '.join(errors[:5])
   raise ValueError('No public candidates could be fetched. '+detail)
  with lock:
   state.update(total=len(candidates),checked=0,working=[],failed=0,status='scanning',sources=inventory,message=f"Fetched {len(candidates)} unique candidates (up to 3× requested target). Verifying exit IP, country and Google connectivity…")
  results=[]
  with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
   futures=[pool.submit(verify_proxy,c) for c in candidates]
   for f in as_completed(futures):
    try: result=f.result()
    except Exception: result=None
    with lock:
     state['checked']+=1
     if result and (country=='ALL' or result['country']==country):
      results.append(result); results.sort(key=lambda x:(x['latency_ms'],x['country']))
      state['working']=results[:maximum].copy()
     else: state['failed']+=1
  with lock:
   results=results[:maximum]
   state['working']=results.copy()
   state['status']='complete'; state['finished_at']=time.time()
   state['message']=f"Completed: {len(results)} genuinely verified proxies passed live exit-IP, country and Google 204 checks. Google RTT limit: {GOOGLE_MAX_LATENCY_MS} ms." + (' Both mode: public feeds were scanned; no private inventory is connected.' if source=='both' else '')
   if errors: state['message']+=' Some feeds unavailable: '+' | '.join(errors[:4])
 except Exception as e:
  with lock: state['status']='error'; state['message']=str(e); state['finished_at']=time.time()
 finally:
  with lock: state['running']=False

@app.before_request
def optional_auth():
 password=os.getenv('DASHBOARD_PASSWORD','').strip()
 if password and request.endpoint not in ('static',):
  from flask import Response
  auth=request.authorization
  if not auth or not __import__('hmac').compare_digest(auth.password or '',password):
   return Response('Authentication required',401,{'WWW-Authenticate':'Basic realm="Proxy Hunter"'})

@app.get('/healthz')
def healthz(): return jsonify(status='ok', version='6.0')

@app.get('/')
def index(): return render_template('index.html')
@app.get('/api/countries')
def countries():
 # ISO-3166 alpha-2 list, used for exit-IP country verification.
 return jsonify('AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW'.split())
@app.get('/api/status')
def status():
 with lock: return jsonify({**state,'working':state['working'][-1000:]})
@app.post('/api/scan')
def start_scan():
 data=request.get_json(silent=True) or {}; country=str(data.get('country','ALL')).upper(); protocol=str(data.get('protocol','all')).lower(); source=str(data.get('source','both')).lower()
 try: maximum=int(data.get('maximum',100))
 except (ValueError,TypeError): return jsonify(error='Maximum must be an integer from 1 to 10,000.'),400
 if not 1<=maximum<=10000: return jsonify(error='Maximum must be between 1 and 10,000.'),400
 if protocol!='all' and protocol not in ALLOWED: return jsonify(error='Unsupported protocol.'),400
 if not re.fullmatch(r'[A-Z]{2}|ALL',country): return jsonify(error='Invalid country code.'),400
 if source not in ('both','public','private'): return jsonify(error='Choose Both, Public or Private.'),400
 with lock:
  if state['running']: return jsonify(error='A scan is already running.'),409
  state.update(running=True,status='starting',total=0,checked=0,working=[],failed=0,requested=maximum,message=('Collecting candidates from public feeds…' if source in ('public','both') else 'Checking private source…'),started_at=time.time(),finished_at=None,sources=[])
 threading.Thread(target=run_scan,args=(source,country,protocol,maximum),daemon=True).start()
 return jsonify(started=True,notice=('Both mode scans configured public feeds. No authorized private inventory is connected, so results are public only.' if source=='both' else None))
@app.get('/api/export')
def export_txt():
 with lock: rows=list(state['working'])
 content='\n'.join((f"{r['ip']}:{r['port']}:{r.get('username')}:{r.get('password')}" if r.get('username') else f"{r['ip']}:{r['port']}") for r in rows)
 return app.response_class(content+'\n' if content else '',mimetype='text/plain',headers={'Content-Disposition':'attachment; filename="proxy_hunter_verified.txt"'})
if __name__=='__main__': app.run(host=os.getenv('HOST','0.0.0.0'),port=int(os.getenv('PORT','5000')),debug=False,threaded=True)
