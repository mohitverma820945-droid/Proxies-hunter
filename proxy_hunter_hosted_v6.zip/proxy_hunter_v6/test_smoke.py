import ast, pathlib, unittest
APP=pathlib.Path(__file__).with_name("app.py")
TREE=ast.parse(APP.read_text())
class StaticSmoke(unittest.TestCase):
 def test_python_ast(self): self.assertIsInstance(TREE, ast.Module)
 def test_feed_inventory_has_twelve_plus_named_sources(self):
  node=next(n for n in TREE.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="FEEDS" for t in n.targets))
  names=set()
  for n in ast.walk(node.value):
   if isinstance(n,ast.Tuple) and n.elts and isinstance(n.elts[0],ast.Constant) and isinstance(n.elts[0].value,str): names.add(n.elts[0].value)
  self.assertGreaterEqual(len(names),12)
 def test_deployment_single_worker(self):
  proc=pathlib.Path(__file__).with_name("Procfile").read_text()
  self.assertIn("--workers 1",proc)
 def test_health_endpoint(self): self.assertIn("/healthz",APP.read_text())
if __name__=="__main__": unittest.main()
