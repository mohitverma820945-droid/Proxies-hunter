const $ = id => document.getElementById(id);
let poller = null;
function esc(v){return String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function render(d){
  $('total').textContent=d.total || (d.status==='idle'?'—':'0'); $('checked').textContent=d.checked||0; $('working').textContent=(d.working||[]).length; $('failed').textContent=d.failed||0; $('message').textContent=d.message||'';
  $('statusTitle').textContent=({idle:'Awaiting scan',starting:'Fetching source list',scanning:'Verifying proxies',complete:'Scan complete',error:'Scan stopped'})[d.status]||'Working';
  const pct=d.total?Math.round(d.checked/d.total*100):0; $('percent').textContent=pct+'%'; $('progressBar').style.width=pct+'%';
  const rows=d.working||[]; $('resultCount').textContent=rows.length+' RESULTS'; $('exportBtn').classList.toggle('disabled',rows.length===0);
  $('results').innerHTML=rows.length?rows.map(r=>`<tr><td>${esc(r.ip)}:${r.port}</td><td>${esc(r.protocol)}</td><td>${esc(r.country)}</td><td>${r.google_latency_ms ?? r.latency_ms} ms</td><td>${esc(r.quality||'VERIFIED')} · ${esc(r.anonymity)}</td></tr>`).join(''):'<tr><td colspan="5" class="empty">No verified proxies yet. Start a live scan.</td></tr>';
  $('scanBtn').disabled=!!d.running; $('scanBtn').textContent=d.running?'Scanning…':'▶  Start live scan'; if(!d.running&&poller){clearInterval(poller);poller=null;}
}
async function refresh(){try{const r=await fetch('/api/status',{cache:'no-store'});if(!r.ok)throw new Error('Status HTTP '+r.status);render(await r.json());}catch(e){$('message').textContent='Status request failed: '+e.message;}}
async function loadCountries(){try{const r=await fetch('/api/countries');const codes=await r.json();const select=$('country');const current=select.value;select.innerHTML='<option value="ALL">All countries</option>'+codes.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');select.value=codes.includes(current)?current:'ALL';}catch(e){}}
$('scanBtn').addEventListener('click',async()=>{
 const maximum=Number($('maximum').value); if(!Number.isInteger(maximum)||maximum<1||maximum>10000){$('message').textContent='Enter a whole number from 1 to 10,000.';return;}
 $('scanBtn').disabled=true;
 try{const r=await fetch('/api/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:$('source').value,country:$('country').value,protocol:$('protocol').value,maximum})});const raw=await r.text();let d;try{d=JSON.parse(raw)}catch{throw new Error('Server returned HTTP '+r.status+' instead of JSON. Check Termux logs.')}if(!r.ok)throw new Error(d.error||'HTTP '+r.status);if(d.notice)$('message').textContent=d.notice;await refresh();if(!poller)poller=setInterval(refresh,1000);}catch(e){$('message').textContent=e.message;$('scanBtn').disabled=false;}
});
loadCountries();refresh();
